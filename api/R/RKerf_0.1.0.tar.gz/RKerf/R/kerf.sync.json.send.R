kerf.sync.json.send <-
function(x,b=list(),addr="localhost",port=1234,unpack.table=TRUE) {
    con <- socketConnection(addr,port=port,open="r+b",blocking=TRUE) 
    out <- kerf.sync.send(kerf.json(x,b),con)
    close(con)
    if(unpack.table) {
        kerf.list.framer(out)
    } else {
        out
    }
}
