kerf.list.framer <-
function(x) {
    out = x
    if(class(x)=="list") {
        keys = names(x)
        lkey = last(keys)
        nkey = length(keys)
        if(lkey=="is_json_table") {
            if(x[[lkey]]==1) {
                out= data.frame(x[keys[-1*nkey]])
            }
        }
    }
    out
}
