rawNulls <-
function(n) {
    rep(as.raw(0),n)
}
