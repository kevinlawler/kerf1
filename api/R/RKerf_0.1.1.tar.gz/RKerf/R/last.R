last <-
function(x) {x[length(x)]}
